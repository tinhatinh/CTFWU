#!/usr/bin/env runghc
{-# LANGUAGE AllowAmbiguousTypes #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE LambdaCase #-}
{-# LANGUAGE NoStarIsType #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE UndecidableSuperClasses #-}
import Data.Kind (Type, Constraint)
import Data.Proxy (Proxy(..))
import GHC.TypeLits (KnownNat, KnownChar, KnownSymbol, UnconsSymbol, CharToNat, NatToChar, Mod, symbolVal, type (<=), type (*))
import Data.List (zipWith6)
import Control.Monad (MonadPlus(mzero), forM_)

import Secrets (KEY)

type M1 = 6
type M2 = 7

data Locale = Alpha | Beta | Gamma | Delta | Epsilon | Zeta deriving Eq

class KnownNat n => LocaleIndex n where
    locale :: Proxy n -> Locale

instance LocaleIndex 0 where
    locale _ = Alpha
instance LocaleIndex 1 where
    locale _ = Beta
instance LocaleIndex 2 where
    locale _ = Gamma
instance LocaleIndex 3 where
    locale _ = Delta
instance LocaleIndex 4 where
    locale _ = Epsilon
instance LocaleIndex 5 where
    locale _ = Zeta

type family AllLocaleIndexable n cs :: Constraint where
    AllLocaleIndexable n 'Nothing = (KnownNat n)
    AllLocaleIndexable n ('Just '(c, cs)) = 
        (KnownNat n, KnownChar c, 
         LocaleIndex        (Mod (n * CharToNat c) M1), 
         AllLocaleIndexable (Mod (n * CharToNat c) M2) (UnconsSymbol cs))

class AllLocaleIndexable n cs => LocaleSet n cs where 
    locales :: Proxy n -> Proxy cs -> [Locale]
instance KnownNat n => LocaleSet n 'Nothing where
    locales _ _ = []
instance ( KnownChar c, KnownNat n 
         , 'A' <= c, c <= '}'
         , LocaleIndex (Mod (n * CharToNat c) M1) 
         , LocaleSet   (Mod (n * CharToNat c) M2) (UnconsSymbol cs)) => LocaleSet n ('Just '(c, cs)) where
    locales _ _ =  locale  (Proxy @(Mod (n * CharToNat c) M1))
                :  locales (Proxy @(Mod (n * CharToNat c) M2)) (Proxy @(UnconsSymbol cs))

type UniversalLocaleSet cs ls = (
    UnconsSymbol cs ~ ls, 
    LocaleSet 1 ls, LocaleSet 2 ls, LocaleSet 3 ls, LocaleSet 4 ls, LocaleSet 5 ls, LocaleSet 6 ls)

data Forms = Forms {person :: String, place :: String, thing :: String, time :: String, method :: String, reason :: String}
             deriving Show
type Dialect = [Forms]

mkForms :: Locale -> Locale -> Locale -> Locale -> Locale -> Locale -> Forms 
mkForms personL placeL thingL timeL methodL reasonL 
    = Forms 
        (case personL of 
           Alpha   -> "You "
           Beta    -> "Yous "
           Gamma   -> "Y'all "
           Delta   -> "You here! "
           Epsilon -> "Ye "
           Zeta    -> "Yuh ")
        (case placeL of 
           Alpha   -> "Here "
           Beta    -> "Heres "
           Gamma   -> "O'er'ere "
           Delta   -> "Here like! "
           Epsilon -> "'ere "
           Zeta    -> "Herr ")
        (case thingL of 
           Alpha   -> "This "
           Beta    -> "These "
           Gamma   -> "Dis "
           Delta   -> "This here! "
           Epsilon -> "'is "
           Zeta    -> "Thass ")
        (case timeL of 
           Alpha   -> "Now "
           Beta    -> "Nows "
           Gamma   -> "'ight now "
           Delta   -> "Here now! "
           Epsilon -> "'ow "
           Zeta    -> "Naw ")
        (case methodL of 
           Alpha   -> "Gently "
           Beta    -> "Gentlies "
           Gamma   -> "Gent'y "
           Delta   -> "Gentle like! "
           Epsilon -> "Gentle "
           Zeta    -> "Gantly ")
        (case reasonL of 
           Alpha   -> "Because "
           Beta    -> "Becauses "
           Gamma   -> "'cause "
           Delta   -> "Like, because! "
           Epsilon -> "'cuz "
           Zeta    -> "Becawse ")

dialect :: forall cs ls. (UniversalLocaleSet cs ls) => Dialect
dialect = zipWith6 mkForms
        (locales (Proxy @1) (Proxy @ls))
        (locales (Proxy @2) (Proxy @ls))
        (locales (Proxy @3) (Proxy @ls))
        (locales (Proxy @4) (Proxy @ls))
        (locales (Proxy @5) (Proxy @ls))
        (locales (Proxy @6) (Proxy @ls))

respond :: IO()
respond = forM_ (dialect @KEY) 
        $ \(Forms personV placeV thingV timeV methodV reasonV) -> getLine 
      >>= mapM_ (\case 
            "Who?"   -> putStr personV
            "Where?" -> putStr placeV
            "What?"  -> putStr thingV
            "When?"  -> putStr timeV
            "How?"   -> putStr methodV
            "Why?"   -> putStr reasonV
            _        -> mzero) . words
       >> putChar '\n'
    
main :: IO()
main = respond
