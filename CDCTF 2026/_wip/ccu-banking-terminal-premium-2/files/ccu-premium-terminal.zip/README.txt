CCU Banking Access Terminal - Premium Tier
Crimson Credit Union - private client node CCU-CORE-4

  ccu_premium            the service binary, as deployed
  libc.so.6              the libc it runs against (Ubuntu GLIBC 2.35-0ubuntu3.15)
  ld-linux-x86-64.so.2   the matching loader
  libseccomp.so.2        the seccomp library it is linked against

To run it locally against the shipped libraries, from a directory that
holds all four files:

  patchelf --set-interpreter ./ld-linux-x86-64.so.2 \
           --set-rpath . ccu_premium
  ./ccu_premium

libseccomp is shipped because your system copy is probably built
against a newer glibc than this one, and the loader will refuse it with
"GLIBC_ABI_DT_RELR not found". Use the one in this directory. Do not
stub it out: it allocates while it builds the filter, so removing it
moves the heap and your exploit will stop matching the server.

A local run has no /flag, so it shows your chain working, not a flag.

The service is hardened with a seccomp-bpf filter. Dump it yourself:

  seccomp-tools dump ./ccu_premium

Test credentials and the flag path are in the challenge description.
