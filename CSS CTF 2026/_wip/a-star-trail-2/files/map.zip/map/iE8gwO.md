# iE8gwO

Coords: 27.067204, 34.307603


[[cy6ByQ]]
[[XcsB3J]]
[[q7WsqL]]
[[wHUEI7]]
[[tfjE3l]]
