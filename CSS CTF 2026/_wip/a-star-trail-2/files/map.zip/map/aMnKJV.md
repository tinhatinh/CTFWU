# aMnKJV

Coords: 47.117688, 82.144521


[[4pX3N7]]
[[ff8w7g]]
[[M3YyEj]]
[[LlVKHk]]
[[SISVom]]
