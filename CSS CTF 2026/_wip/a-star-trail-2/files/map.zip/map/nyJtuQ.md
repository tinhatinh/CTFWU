# nyJtuQ

Coords: 17.610425, 42.914682


[[3YTuSz]]
[[Q6dg3i]]
[[XXjrIz]]
[[omApg8]]
[[Qsozc4]]
