# QSMDQr

Coords: 37.366935, 28.268789


[[yaKc1l]]
[[h51gNQ]]
[[xfESrz]]
[[ZHRuCk]]
[[DRuCQ7]]
