# nbjC4w

Coords: 6.926644, 18.786758


[[t3YQX1]]
[[fJPkBk]]
[[Fmwuhh]]
[[JYQdeE]]
[[74fAGD]]
[[DMRM77]]
[[Inh2ni]]
