# CQGEFd

Coords: 44.096825, 42.714420


[[4xjRMc]]
[[LMdJ5T]]
[[UI6ZN7]]
[[baPpvj]]
