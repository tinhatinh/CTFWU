# I15dEE

Coords: 43.370497, 69.311585


[[Tk7fCt]]
[[JnMaL4]]
[[J3ECmz]]
[[cRneMx]]
[[ggewpG]]
[[NJTIze]]
