# uGqzs3

Coords: 48.369684, 34.794025


[[YtDdTS]]
[[8Fus6A]]
[[EBCje0]]
[[05MT62]]
