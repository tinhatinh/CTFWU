# w6QLC7

Coords: 15.842801, 64.342175


[[0HW83E]]
[[t78Q4f]]
[[zyJS3S]]
[[0efGfa]]
[[gOFlZS]]
