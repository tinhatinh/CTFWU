# X3uEiD

Coords: 45.314355, 31.677257


[[9OSL7C]]
[[7pDMfo]]
[[KScmIE]]
[[tyLCRX]]
[[vOhmbN]]
[[BwDVr6]]
