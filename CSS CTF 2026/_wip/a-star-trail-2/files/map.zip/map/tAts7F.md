# tAts7F

Coords: 34.983616, 69.109345


[[a40xR5]]
[[u9gBjq]]
[[CmiqPX]]
[[FQFM6C]]
[[ZrG7qf]]
[[IPil7I]]
