# rGpSjk

Coords: 29.247603, 47.227707


[[ZKlGW9]]
[[UWpOYy]]
[[KiokCX]]
[[DFMvSC]]
[[kTsgZW]]
[[b2gOtd]]
