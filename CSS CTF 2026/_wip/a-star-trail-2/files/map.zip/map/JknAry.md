# JknAry

Coords: 17.627117, 15.379383


[[Bj68lj]]
[[EDC0mD]]
[[wua0fa]]
[[aiNLq6]]
[[tOOkeW]]
[[6T76Az]]
[[MR8uJc]]
