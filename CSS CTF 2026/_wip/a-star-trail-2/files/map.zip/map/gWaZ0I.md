# gWaZ0I

Coords: 35.210649, 56.094555


[[P81fyf]]
[[eSQGsd]]
[[z0X22p]]
[[kxZmLq]]
[[5YpcqG]]
[[MwZSSE]]
