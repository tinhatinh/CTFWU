# 5Ot6uS

Coords: 44.616469, 47.699529


[[NsMoDt]]
[[2FZZhc]]
[[oXjWpL]]
[[qPSddX]]
[[Oj4wpt]]
