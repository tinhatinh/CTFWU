# jsTKAy

Coords: 38.630642, 38.459248


[[Db9eLC]]
[[pZsZl1]]
[[XRR5nD]]
[[PU1VFf]]
[[yN1Lw4]]
