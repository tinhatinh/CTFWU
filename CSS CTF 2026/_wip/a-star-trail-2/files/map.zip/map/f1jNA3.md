# f1jNA3

Coords: 12.265983, 0.696346


[[KLGcXj]]
[[Q6cjZx]]
[[bGa5dA]]
[[Lf2DL8]]
[[wnkGkJ]]
[[6G7LHu]]
