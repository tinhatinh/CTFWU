# 0FIKBo

Coords: 48.357611, 60.174896


[[L5R9IO]]
[[1369XL]]
[[cyC1Zk]]
[[SRdnO1]]
[[1RajU8]]
