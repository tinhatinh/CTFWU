# e42ROh

Coords: 1.806730, 68.930986


[[46S0xq]]
[[kb1qAa]]
[[uk9hC4]]
[[bMWrFL]]
[[S1oIbU]]
