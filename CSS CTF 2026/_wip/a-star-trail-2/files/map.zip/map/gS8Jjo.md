# gS8Jjo

Coords: 20.791081, 18.402974


[[IA4Y6B]]
[[i0yJPG]]
[[IfiAIW]]
[[rTXoeF]]
[[8b0xr1]]
[[PpowW7]]
