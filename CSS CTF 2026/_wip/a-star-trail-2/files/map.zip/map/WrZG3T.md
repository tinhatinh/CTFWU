# WrZG3T

Coords: 41.253416, 34.254742


[[8DQ4l7]]
[[7UoG9Q]]
[[Y2PKTF]]
[[yf8n5V]]
[[EmbT5n]]
