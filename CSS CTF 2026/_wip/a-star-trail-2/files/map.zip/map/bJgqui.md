# bJgqui

Coords: 45.591175, 29.353970


[[KScmIE]]
[[LXDdKh]]
[[LhoScO]]
[[1cRRFC]]
[[v2MxYL]]
[[tyLCRX]]
