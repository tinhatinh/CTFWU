# WtvG20

Coords: 34.978468, 33.336945


[[KgxAJF]]
[[HpmIgU]]
[[dlZ5U5]]
[[WXcPnB]]
