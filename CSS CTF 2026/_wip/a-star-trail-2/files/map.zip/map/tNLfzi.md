# tNLfzi

Coords: 30.231659, 36.817413


[[rGaxPK]]
[[TeLUb1]]
[[xF78mo]]
[[TfwXVS]]
[[NuihxM]]
[[IBKTDX]]
