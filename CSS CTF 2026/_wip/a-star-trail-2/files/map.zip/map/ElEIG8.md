# ElEIG8

Coords: 30.693589, 5.892812


[[wNITqK]]
[[ichOqs]]
[[7Ix2V7]]
[[baWP8q]]
[[0oPSl0]]
[[fuldKB]]
[[iPkdk0]]
