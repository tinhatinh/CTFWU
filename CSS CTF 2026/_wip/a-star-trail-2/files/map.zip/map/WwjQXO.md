# WwjQXO

Coords: 47.989512, 80.474374


[[2SgLTt]]
[[w8hXuB]]
[[BoKpxr]]
[[ZB99Tk]]
[[mS9YBN]]
