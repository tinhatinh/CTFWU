# bduIYR

Coords: 47.122781, 90.637518


[[rI0Q3g]]
[[x8L6Pw]]
[[CqfDjf]]
[[AoPC8P]]
[[6mj5il]]
