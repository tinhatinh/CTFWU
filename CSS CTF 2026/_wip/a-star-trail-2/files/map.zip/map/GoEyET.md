# GoEyET

Coords: 46.442418, 69.403986


[[jtV9qw]]
[[tMoG1w]]
[[uOEwEJ]]
[[sso6B9]]
[[ACPgP1]]
[[tCL8Oi]]
